public interface ICostFunction {
	float CostFunction(int idx1, int idx2);
}