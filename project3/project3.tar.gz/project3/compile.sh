#!/bin/sh
dmcs ./source/app.cs ./source/tests.cs ./source/fsm.cs
