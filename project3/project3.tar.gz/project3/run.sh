#!/bin/sh

# Call me thusly for dev:
# ./run.sh </opt/dropbox/12-13/473/project3/fsm-input.utf8.txt >/home2/www-uakari/html/473/YOUR-PATAS-ID.html

mono ./source/app.exe $*
