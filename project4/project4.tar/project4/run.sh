#!/bin/sh
java -cp ./source -Xmx1g App $*