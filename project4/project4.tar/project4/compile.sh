#!/bin/sh
javac ./source/App.java ./source/BuildTrie.java ./source/SearchTrie.java ./source/Trie.java ./source/Tests.java