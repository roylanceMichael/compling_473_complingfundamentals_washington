#!/bin/sh
javac ./source/App.java ./source/Tests.java ./source/BayesianReporter.java