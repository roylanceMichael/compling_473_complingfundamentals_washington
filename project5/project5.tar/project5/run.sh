#!/bin/sh
java -Dfile.encoding=ISO88591 -cp ./source -Xmx1g App $*